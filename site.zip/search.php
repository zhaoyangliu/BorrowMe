<?php

// Facebook Login and access
require_once('facebook.php');

  $config = array(
    'appId' => '588618324507077',
    'secret' => '2617da03e8a7ff6cbc8e838e98b3fec4',
    'cookie' => true,
  );



$facebook = new Facebook($config);
$user_id = $facebook->getUser();
$access_token = $facebook->getAccessToken();


echo $access_token;
echo "<br>";
echo $user_id;
echo "<br>";


if($user_id) {
      try {
      	$friends = $facebook->api('/me/friends',array('access_token'=>$my_access_token));
      } 
      catch(FacebookApiException $e) 
      {	
  	$loginUrl = $facebook->getLoginUrl(array('scope'=>'offline_access','redirect_uri'=>'http://liuzy.net/BorrowMe/Dev/jquerysite.php#searchpage'));
  	echo "<a href=".$loginUrl.">login</a><br>";
	error_log($e);
      }   
    }
	if ($user_id) {
		$logoutUrl = $facebook->getLogoutUrl();
		} 
		else {
		$loginUrl = $facebook->getLoginUrl(array('scope'=>'offline_access'));
		}

    if ($user_id) {
        $user_profile = $facebook->api('/me');
        //$friends = $facebook->api('/me/friends');
	}
	
	echo "<b>friends:</b>";
	echo $friends;
	echo $user_profile;
	
	$fliststr = "(";
	//foreach ($friends as $friend) {
	foreach (array('Andrew Jiang') as $friend) {
		$fliststr = $fliststr . "'" . $friend . "',";
	}
	$fliststr = $fliststr . ")";
// --------------------------  
  
	$category = $_GET['q'];
	$MYSQL_server_name = "mysql21.freehostia.com";
	$MYSQL_server_username = "zhaliu0_market";
	$MYSQL_server_password = "0077049";
	$DB_name = "zhaliu0_market";

	$server = @mysqli_connect($MYSQL_server_name, $MYSQL_server_username, $MYSQL_server_password, $DB_name );

	if (!$server) {
	echo "Could not get server";
	exit();
	}

	mysqli_select_db($server,"zhaliu0_market");
	$query = "SELECT * FROM `items` WHERE `item_cat`='$category' AND 'item_owner' IN '$fliststr'";
	$result = mysqli_query($server, $query);

  	if($result) 
   	{
   	while($row=mysqli_fetch_row($result)) {
   	     
   		echo "<h3><a href='http://liuzy.net/BorrowMe/jquerysite.php#iteminfo' onclick='getItemInfo(" . $row[0] . ")'>" . $row[1] . "</a></h3>";
   		echo "<p>" . $row[2] . "</p>";
   		echo "<br><br>";
   		}
   	}
   	$server->close();
 ?>
<?php

$item_name= addslashes($_POST['itemname']);
$item_cat = $_POST['radio-choice-1'];
$item_desc = addslashes($_POST['descrip']);
$owner = addslashes($_POST['owner']);
$owner_id = $_POST['item_owner'];
$contactemail = addslashes($_POST['contactemail']);
$contactphone = addslashes($_POST['contactphone']);
$today = date("m/j/y");
date_timezone_set($date, timezone_open('America/Chicago')); 


header( 'Location: http://liuzy.net/BorrowMe/jquerysite.php#uppage');

if (empty($item_name) || empty($item_owner) || empty($contact))
{
	echo "empty";
}



if(!empty($item_name) && !empty($owner) && !empty($contactphone) && !empty($contactemail))
{
	$MYSQL_server_name = "mysql21.freehostia.com";
	$MYSQL_server_username = "zhaliu0_market";
	$MYSQL_server_password = "0077049";
	$DB_name = "zhaliu0_market";

	$server = @mysqli_connect($MYSQL_server_name, $MYSQL_server_username, $MYSQL_server_password, $DB_name );

	if (!$server) {
	echo "Could not get server";
	exit();
	}

	mysqli_select_db($server,"zhaliu0_market");
		$query="INSERT INTO items (item_name,item_cat,item_desc,owner,item_owner, contactphone,contactemail) 
		VALUES('$item_name','$item_cat','$item_desc','$owner','$owner_id','$contactphone','$contactemail')";
	
	
	if(!mysqli_query($server,$query)){ 
		echo "<script type='text/javascript/>alert('Unsuccessfully entered')</script>";
		header( 'Location: http://liuzy.net/BorrowMe/jquerysite.php#failed' );
	}
	else {
		echo "query success:  $query";
		header( 'Location: http://liuzy.net/BorrowMe/jquerysite.php#confirmed' );
	}
}
   

?>
<?php
session_start();
session_destroy();
echo '<a href="jquerysite.php">Proceed to home page</a>.';
?>